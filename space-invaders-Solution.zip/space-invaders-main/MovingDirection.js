const MovingDirection = {
  left: 0,
  right: 1,
  downLeft: 2,
  downRight: 3,
};

export default MovingDirection;
